import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import Image from "next/image";

interface PlayerTier {
  gamemode: string;
  tier: string;
  icon: string;
}

interface PlayerData {
  username: string;
  title: string;
  region: string;
  position: number;
  points: number;
  avatar: string;
  tiers: PlayerTier[];
}

interface PlayerSearchModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  playerData: PlayerData | null;
  notFound: boolean;
}

const tierColors: Record<string, { bg: string; text: string }> = {
  HT1: { bg: 'bg-[#000000]', text: 'text-[#fbbf24]' },
  LT1: { bg: 'bg-[#1a1410]', text: 'text-[#fbbf24]' },
  HT2: { bg: 'bg-[#0a0a0a]', text: 'text-[#94a3b8]' },
  LT2: { bg: 'bg-[#2a2420]', text: 'text-[#94a3b8]' },
  HT3: { bg: 'bg-[#141414]', text: 'text-[#fb923c]' },
  LT3: { bg: 'bg-[#3d3025]', text: 'text-[#fb923c]' },
  HT4: { bg: 'bg-[#1e1e1e]', text: 'text-[#94a3b8]' },
  LT4: { bg: 'bg-[#4d4030]', text: 'text-[#94a3b8]' },
  HT5: { bg: 'bg-[#282828]', text: 'text-[#fb923c]' },
  LT5: { bg: 'bg-[#5d5035]', text: 'text-[#fb923c]' },
};

export function PlayerSearchModal({ open, onOpenChange, playerData, notFound }: PlayerSearchModalProps) {
  if (notFound) {
    return (
      <Dialog open={open} onOpenChange={onOpenChange}>
        <DialogContent className="bg-[#111827] border-border max-w-md">
          <DialogHeader>
            <DialogTitle className="text-2xl font-bold text-center">Player Not Found</DialogTitle>
          </DialogHeader>
          <div className="py-8 text-center">
            <p className="text-muted-foreground">
              No player found with that username. Please try again.
            </p>
          </div>
        </DialogContent>
      </Dialog>
    );
  }

  if (!playerData) return null;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="bg-[#111827] border-border max-w-2xl">
        <div className="flex flex-col items-center gap-6 py-4">
          {/* Player Avatar */}
          <div className="relative w-32 h-32 rounded-full border-4 border-primary overflow-hidden">
            <Image
              src={playerData.avatar}
              alt={playerData.username}
              fill
              className="object-cover"
              style={{ imageRendering: 'pixelated' }}
            />
          </div>

          {/* Player Name */}
          <h2 className="text-4xl font-bold bg-gradient-to-r from-[#84cc16] to-[#fbbf24] bg-clip-text text-transparent">
            {playerData.username}
          </h2>

          {/* Region */}
          <div className="text-muted-foreground text-lg">
            {playerData.region}
          </div>

          {/* Position */}
          <div className="bg-gradient-to-r from-[#78350f] to-[#78350f]/50 px-8 py-4 rounded-xl border border-[#fbbf24]/30">
            <div className="text-center">
              <div className="text-6xl font-bold text-[#fbbf24] mb-2">
                {playerData.position}.
              </div>
              <div className="text-lg font-semibold text-foreground">
                OVERALL ({playerData.points} points)
              </div>
            </div>
          </div>

          {/* Tiers Section */}
          <div className="w-full">
            <h3 className="text-xl font-bold mb-4 text-center text-muted-foreground">TIERS</h3>
            <div className="grid grid-cols-4 md:grid-cols-8 gap-4">
              {playerData.tiers.map((tier, index) => {
                const colors = tierColors[tier.tier] || { bg: 'bg-muted', text: 'text-muted-foreground' };
                return (
                  <div key={index} className="flex flex-col items-center gap-2">
                    <div className={`w-12 h-12 rounded-full ${colors.bg} flex items-center justify-center`}>
                      <Image
                        src={tier.icon}
                        alt={tier.gamemode}
                        width={24}
                        height={24}
                        className="object-contain"
                      />
                    </div>
                    <span className={`text-xs font-bold ${colors.text}`}>
                      {tier.tier}
                    </span>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}