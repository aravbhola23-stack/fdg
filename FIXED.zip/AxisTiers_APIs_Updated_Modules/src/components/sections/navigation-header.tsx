"use client";

import Link from "next/link";
import { Search, Menu, Trophy, Home } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Sheet,
  SheetContent,
  SheetTrigger,
} from "@/components/ui/sheet";
import { usePathname } from "next/navigation";
import { useState, useEffect } from "react";
import { PlayerSearchModal } from "@/components/player-search-modal";

const navLinks = [
  {
    href: "/",
    label: "Home",
    icon: Home,
  },
  {
    href: "/rankings/overall",
    label: "Rankings",
    icon: Trophy,
  },
  {
    href: "https://discord.gg/axistiers",
    label: "Join Discord",
    icon: null,
    external: true,
  },
];

interface ApiPlayer {
  ign: string;
  tier?: string;
  region?: "NA" | "EU" | "SA" | "AS" | "AU";
  total?: number;
  modes?: Record<string, string>;
}

export default function NavigationHeader() {
  const pathname = usePathname();
  const [searchQuery, setSearchQuery] = useState("");
  const [modalOpen, setModalOpen] = useState(false);
  const [playerData, setPlayerData] = useState<any>(null);
  const [notFound, setNotFound] = useState(false);
  const [allPlayers, setAllPlayers] = useState<ApiPlayer[]>([]);

  // Fetch all players from overall rankings for search
  useEffect(() => {
    const fetchPlayers = async () => {
      try {
        const response = await fetch('/api/rankings/overall');
        if (response.ok) {
          const data = await response.json();
          setAllPlayers(data.players || []);
        }
      } catch (error) {
        console.error("Failed to fetch players for search:", error);
      }
    };
    
    fetchPlayers();
  }, []);

  const handleSearch = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!searchQuery.trim()) return;

    // Search through local rankings data
    const searchTerm = searchQuery.trim().toLowerCase();
    const foundPlayer = allPlayers.find(
      (player) => player.ign.toLowerCase() === searchTerm
    );

    if (!foundPlayer) {
      setNotFound(true);
      setPlayerData(null);
      setModalOpen(true);
      setSearchQuery("");
      return;
    }

    // Calculate rank
    const rank = allPlayers.findIndex((p) => p.ign === foundPlayer.ign) + 1;

    // Transform to modal format
    const transformedData = {
      username: foundPlayer.ign,
      title: "Combat Specialist",
      region: foundPlayer.region === "NA" ? "North America" : foundPlayer.region || "Unknown",
      position: rank,
      points: foundPlayer.total || 0,
      avatar: `https://render.crafty.gg/3d/bust/${encodeURIComponent(foundPlayer.ign)}`,
      tiers: foundPlayer.modes
        ? Object.entries(foundPlayer.modes).map(([gamemode, tier]) => ({
            gamemode,
            tier: tier as string,
            icon: getGameModeIcon(gamemode),
          }))
        : [],
    };

    setPlayerData(transformedData);
    setNotFound(false);
    setModalOpen(true);
    setSearchQuery("");
  };

  const getGameModeIcon = (mode: string): string => {
    const icons: Record<string, string> = {
      crystal: "https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/425ffaba-197f-44f7-b59e-aabfd2a5bd4d-mctiers-com/assets/svgs/vanilla-6.svg?",
      uhc: "https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/425ffaba-197f-44f7-b59e-aabfd2a5bd4d-mctiers-com/assets/svgs/uhc-7.svg?",
      diapot: "https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/425ffaba-197f-44f7-b59e-aabfd2a5bd4d-mctiers-com/assets/svgs/pot-8.svg?",
      nethpot: "https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/425ffaba-197f-44f7-b59e-aabfd2a5bd4d-mctiers-com/assets/svgs/nethop-9.svg?",
      smp: "https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/425ffaba-197f-44f7-b59e-aabfd2a5bd4d-mctiers-com/assets/svgs/smp-10.svg?",
      sword: "https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/425ffaba-197f-44f7-b59e-aabfd2a5bd4d-mctiers-com/assets/svgs/sword-11.svg?",
      axe: "https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/425ffaba-197f-44f7-b59e-aabfd2a5bd4d-mctiers-com/assets/svgs/axe-12.svg?",
    };
    return icons[mode.toLowerCase()] || "";
  };

  return (
    <>
      <header className="max-w-[1352px] h-16 mx-auto rounded-xl bg-[#121822] border-2 border-border flex items-center justify-between gap-2 px-4 z-50 animate-fade-in">
        <div className="flex items-center gap-10">
          <Link href="/" className="flex items-center group">
            <h1 className="bg-gradient-to-r from-[#84cc16] to-[#fbbf24] bg-clip-text font-mono text-3xl font-extrabold tracking-[-0.07em] text-transparent transition-all duration-300 group-hover:scale-105">
              Axis Tiers
            </h1>
          </Link>
          <nav className="hidden md:flex">
            <ul className="flex items-center gap-2">
              {navLinks.map((link) => {
                const IconComponent = link.icon;
                const isActive = link.href === "/" 
                  ? pathname === "/" 
                  : pathname.startsWith("/rankings");
                
                if (link.external) {
                  return (
                    <li key={link.label}>
                      <a
                        href={link.href}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="group flex items-center gap-2 p-2 px-4 text-base font-medium transition-all duration-300 bg-[#5865f2] hover:bg-[#4752c4] text-white rounded-lg hover:scale-105"
                      >
                        <svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor">
                          <path d="M20.317 4.37a19.791 19.791 0 0 0-4.885-1.515a.074.074 0 0 0-.079.037c-.21.375-.444.864-.608 1.25a18.27 18.27 0 0 0-5.487 0a12.64 12.64 0 0 0-.617-1.25a.077.077 0 0 0-.079-.037A19.736 19.736 0 0 0 3.677 4.37a.07.07 0 0 0-.032.027C.533 9.046-.32 13.58.099 18.057a.082.082 0 0 0 .031.057a19.9 19.9 0 0 0 5.993 3.03a.078.078 0 0 0 .084-.028a14.09 14.09 0 0 0 1.226-1.994a.076.076 0 0 0-.041-.106a13.107 13.107 0 0 1-1.872-.892a.077.077 0 0 1-.008-.128a10.2 10.2 0 0 0 .372-.292a.074.074 0 0 1 .077-.01c3.928 1.793 8.18 1.793 12.062 0a.074.074 0 0 1 .078.01c.12.098.246.198.373.292a.077.077 0 0 1-.006.127a12.299 12.299 0 0 1-1.873.892a.077.077 0 0 0-.041.107c.36.698.772 1.362 1.225 1.993a.076.076 0 0 0 .084.028a19.839 19.839 0 0 0 6.002-3.03a.077.077 0 0 0 .032-.054c.5-5.177-.838-9.674-3.549-13.66a.061.061 0 0 0-.031-.03zM8.02 15.33c-1.183 0-2.157-1.085-2.157-2.419c0-1.333.956-2.419 2.157-2.419c1.21 0 2.176 1.096 2.157 2.42c0 1.333-.956 2.418-2.157 2.418zm7.975 0c-1.183 0-2.157-1.085-2.157-2.419c0-1.333.955-2.419 2.157-2.419c1.21 0 2.176 1.096 2.157 2.42c0 1.333-.946 2.418-2.157 2.418z"/>
                        </svg>
                        <span>{link.label}</span>
                      </a>
                    </li>
                  );
                }
                
                return (
                  <li key={link.label}>
                    <Link
                      href={link.href}
                      className={`group flex items-center gap-2 p-2 text-base font-medium transition-all duration-300 hover:scale-105 ${
                        isActive
                          ? "text-foreground"
                          : "text-muted-foreground hover:text-foreground"
                      }`}
                    >
                      <IconComponent className="h-5 w-5" />
                      <span>{link.label}</span>
                    </Link>
                  </li>
                );
              })}
            </ul>
          </nav>
        </div>

        <div className="flex items-center gap-2">
          <form onSubmit={handleSearch} className="hidden md:flex items-center gap-2 rounded-full bg-input/40 h-10 px-2 w-full max-w-52 transition-all duration-300 focus-within:ring-2 focus-within:ring-primary/50">
            <Search className="h-5 w-5 text-muted-foreground ml-1 flex-shrink-0" />
            <Input
              type="search"
              placeholder="Search player..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="h-full border-none bg-transparent p-0 text-sm ring-offset-0 placeholder:text-muted-foreground focus-visible:ring-0 w-full"
            />
            <kbd className="hidden select-none items-center rounded bg-muted px-2 py-1 font-mono text-xs font-medium text-muted-foreground lg:inline-flex">
              /
            </kbd>
          </form>

          <Sheet>
            <SheetTrigger asChild>
              <Button variant="ghost" size="icon" className="md:hidden">
                <Menu className="h-6 w-6" />
                <span className="sr-only">Toggle Menu</span>
              </Button>
            </SheetTrigger>
            <SheetContent side="right" className="w-[300px] border-l-border bg-background">
              <nav className="mt-8 flex flex-col gap-4">
                {navLinks.map((link) => {
                  const IconComponent = link.icon;
                  const isActive = link.href === "/" 
                    ? pathname === "/" 
                    : pathname.startsWith("/rankings");
                  
                  if (link.external) {
                    return (
                      <a
                        key={link.label}
                        href={link.href}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="flex items-center gap-3 p-2 px-4 text-lg font-medium transition-colors bg-[#5865f2] hover:bg-[#4752c4] text-white rounded-lg"
                      >
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="currentColor">
                          <path d="M20.317 4.37a19.791 19.791 0 0 0-4.885-1.515a.074.074 0 0 0-.079.037c-.21.375-.444.864-.608 1.25a18.27 18.27 0 0 0-5.487 0a12.64 12.64 0 0 0-.617-1.25a.077.077 0 0 0-.079-.037A19.736 19.736 0 0 0 3.677 4.37a.07.07 0 0 0-.032.027C.533 9.046-.32 13.58.099 18.057a.082.082 0 0 0 .031.057a19.9 19.9 0 0 0 5.993 3.03a.078.078 0 0 0 .084-.028a14.09 14.09 0 0 0 1.226-1.994a.076.076 0 0 0-.041-.106a13.107 13.107 0 0 1-1.872-.892a.077.077 0 0 1-.008-.128a10.2 10.2 0 0 0 .372-.292a.074.074 0 0 1 .077-.01c3.928 1.793 8.18 1.793 12.062 0a.074.074 0 0 1 .078.01c.12.098.246.198.373.292a.077.077 0 0 1-.006.127a12.299 12.299 0 0 1-1.873.892a.077.077 0 0 0-.041.107c.36.698.772 1.362 1.225 1.993a.076.076 0 0 0 .084.028a19.839 19.839 0 0 0 6.002-3.03a.077.077 0 0 0 .032-.054c.5-5.177-.838-9.674-3.549-13.66a.061.061 0 0 0-.031-.03zM8.02 15.33c-1.183 0-2.157-1.085-2.157-2.419c0-1.333.956-2.419 2.157-2.419c1.21 0 2.176 1.096 2.157 2.42c0 1.333-.956 2.418-2.157 2.418zm7.975 0c-1.183 0-2.157-1.085-2.157-2.419c0-1.333.955-2.419 2.157-2.419c1.21 0 2.176 1.096 2.157 2.42c0 1.333-.946 2.418-2.157 2.418z"/>
                        </svg>
                        {link.label}
                      </a>
                    );
                  }
                  
                  return (
                    <Link
                      key={link.label}
                      href={link.href}
                      className={`flex items-center gap-3 p-2 text-lg font-medium transition-colors ${
                        isActive
                          ? "text-foreground"
                          : "text-muted-foreground hover:text-foreground"
                      }`}
                    >
                      <IconComponent className="h-6 w-6" />
                      {link.label}
                    </Link>
                  );
                })}
              </nav>
            </SheetContent>
          </Sheet>
        </div>
      </header>

      <PlayerSearchModal
        open={modalOpen}
        onOpenChange={setModalOpen}
        playerData={playerData}
        notFound={notFound}
      />
    </>
  );
}