"use client";

import Image from "next/image";
import { cn } from "@/lib/utils";
import { useEffect, useState } from "react";
import { Dialog, DialogContent } from "@/components/ui/dialog";
import { X } from "lucide-react";

interface ApiPlayer {
  ign: string;
  tier?: string;
  region?: "NA" | "EU" | "SA" | "AS" | "AU";
  total?: number;
  modes?: Record<string, string>;
}

interface ApiResponse {
  gamemode?: string;
  players: ApiPlayer[];
}

interface RankingsTableProps {
  category: string;
}

const getRegionClasses = (region?: string) => {
  if (!region) return "bg-muted text-muted-foreground";
  switch (region) {
    case "NA": return "bg-region-na text-red-100";
    case "EU": return "bg-region-eu text-green-100";
    case "AS": return "bg-region-as text-purple-100";
    case "AU": return "bg-region-au text-orange-100";
    case "SA": return "bg-region-sa text-cyan-100";
    default: return "bg-muted text-muted-foreground";
  }
};

// Darker = Higher tier (HT), Lighter = Lower tier (LT)
const getTierClasses = (tier?: string) => {
  if (!tier) return "border-muted-foreground/30 text-muted-foreground/50 bg-muted/20";
  
  // Distinguish between HT and LT
  const isHT = tier.startsWith("HT");
  const tierNumber = tier.substring(2, 3);
  
  if (tierNumber === "1") {
    // HT1 = darker, LT1 = lighter
    return isHT 
      ? "border-[#fbbf24] text-[#fbbf24] bg-[#000000]" // HT1: Pure black
      : "border-[#fbbf24] text-[#fbbf24] bg-[#1a1410]"; // LT1: Lighter
  } else if (tierNumber === "2") {
    return isHT
      ? "border-[#94a3b8] text-[#94a3b8] bg-[#0a0a0a]" // HT2: Nearly black
      : "border-[#94a3b8] text-[#94a3b8] bg-[#2a2420]"; // LT2: Lighter
  } else if (tierNumber === "3") {
    return isHT
      ? "border-[#fb923c] text-[#fb923c] bg-[#141414]" // HT3: Very dark
      : "border-[#fb923c] text-[#fb923c] bg-[#3d3025]"; // LT3: Lighter
  } else if (tierNumber === "4") {
    return isHT
      ? "border-[#94a3b8] text-[#94a3b8] bg-[#1e1e1e]" // HT4: Dark
      : "border-[#94a3b8] text-[#94a3b8] bg-[#4d4030]"; // LT4: Lighter
  } else if (tierNumber === "5") {
    return isHT
      ? "border-[#fb923c] text-[#fb923c] bg-[#282828]" // HT5: Medium dark
      : "border-[#fb923c] text-[#fb923c] bg-[#5d5035]"; // LT5: Lightest
  }
  return "border-muted-foreground/30 text-muted-foreground/50 bg-muted/20";
};

const getRankClasses = (rank: number) => {
  if (rank === 1) return "bg-gradient-to-br from-[#fbbf24] to-[#f59e0b] text-[#78350f]";
  if (rank === 2) return "bg-gradient-to-br from-[#94a3b8] to-[#64748b] text-[#1e293b]";
  if (rank === 3) return "bg-gradient-to-br from-[#fb923c] to-[#f97316] text-[#7c2d12]";
  if (rank <= 10) return "bg-gradient-to-br from-[#6366f1] to-[#4f46e5] text-white";
  return "bg-[#1e293b] text-muted-foreground";
};

// Game mode icons mapping
const gameModeIcons: Record<string, string> = {
  crystal: "https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/425ffaba-197f-44f7-b59e-aabfd2a5bd4d-mctiers-com/assets/svgs/vanilla-6.svg?",
  uhc: "https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/425ffaba-197f-44f7-b59e-aabfd2a5bd4d-mctiers-com/assets/svgs/uhc-7.svg?",
  diapot: "https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/425ffaba-197f-44f7-b59e-aabfd2a5bd4d-mctiers-com/assets/svgs/pot-8.svg?",
  nethpot: "https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/425ffaba-197f-44f7-b59e-aabfd2a5bd4d-mctiers-com/assets/svgs/nethop-9.svg?",
  smp: "https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/425ffaba-197f-44f7-b59e-aabfd2a5bd4d-mctiers-com/assets/svgs/smp-10.svg?",
  sword: "https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/425ffaba-197f-44f7-b59e-aabfd2a5bd4d-mctiers-com/assets/svgs/sword-11.svg?",
  axe: "https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/425ffaba-197f-44f7-b59e-aabfd2a5bd4d-mctiers-com/assets/svgs/axe-12.svg?",
};

const getShimmerSvg = (rank: number) => {
  if (rank === 1) return "https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/425ffaba-197f-44f7-b59e-aabfd2a5bd4d-mctiers-com/assets/svgs/1-shimmer-14.svg?";
  if (rank === 2) return "https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/425ffaba-197f-44f7-b59e-aabfd2a5bd4d-mctiers-com/assets/svgs/2-shimmer-15.svg?";
  if (rank === 3) return "https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/425ffaba-197f-44f7-b59e-aabfd2a5bd4d-mctiers-com/assets/svgs/3-shimmer-16.svg?";
  return null;
};

// Overall view - rows with rank numbers
const PlayerRow = ({ 
  player, 
  rank, 
  category,
  onPlayerClick 
}: { 
  player: ApiPlayer; 
  rank: number; 
  category: string;
  onPlayerClick: () => void 
}) => {
  const isOverall = category === "overall";
  
  return (
    <div 
      onClick={onPlayerClick}
      className={cn(
        "flex items-center gap-3 p-3 rounded-lg cursor-pointer transition-all duration-200 border-2",
        rank === 1 ? "bg-gradient-to-r from-[#78350f]/30 to-transparent border-[#fbbf24]/30 hover:border-[#fbbf24]/50" :
        rank === 2 ? "bg-gradient-to-r from-[#334155]/30 to-transparent border-[#94a3b8]/30 hover:border-[#94a3b8]/50" :
        rank === 3 ? "bg-gradient-to-r from-[#7c2d12]/30 to-transparent border-[#fb923c]/30 hover:border-[#fb923c]/50" :
        "bg-[#151a23] border-[#1f2937] hover:bg-[#1f2531] hover:border-[#384152]"
      )}
    >
      <div className={cn(
        "flex items-center justify-center w-10 h-10 rounded-lg font-bold text-lg shrink-0",
        getRankClasses(rank)
      )}>
        {rank}
      </div>

      {/* 3D Bust Model for overall view too */}
      <div className="relative w-12 h-16 rounded-md overflow-hidden border-2 border-border shrink-0">
        <Image
          src={`https://render.crafty.gg/3d/bust/${encodeURIComponent(player.ign)}`}
          alt={player.ign}
          width={48}
          height={64}
          className="object-contain"
          style={{ imageRendering: 'pixelated' }}
          onError={(e) => {
            e.currentTarget.src = `https://mc-heads.net/avatar/${player.ign}/48`;
          }}
        />
      </div>

      <div className="flex-1 min-w-0">
        <h3 className="text-base font-bold text-slate-100 break-words">{player.ign}</h3>
        {player.total !== undefined && (
          <p className="text-xs text-muted-foreground">{player.total} points</p>
        )}
      </div>

      <div className="flex items-center gap-2 shrink-0">
        {player.region && (
          <div className={cn(
            "px-2.5 py-0.5 rounded-full text-xs font-bold",
            getRegionClasses(player.region)
          )}>
            {player.region}
          </div>
        )}
        
        {player.tier && (
          <div className={cn(
            "px-2 py-0.5 text-xs font-bold rounded border-2",
            getTierClasses(player.tier)
          )}>
            {player.tier}
          </div>
        )}
      </div>
    </div>
  );
};

// Gamemode view - tier columns with 3D bust models
const PlayerCard = ({ 
  player, 
  onPlayerClick 
}: { 
  player: ApiPlayer; 
  onPlayerClick: () => void 
}) => {
  const tierClasses = getTierClasses(player.tier);
  
  return (
    <div 
      onClick={onPlayerClick}
      className="flex items-center gap-3 p-3 rounded-lg bg-[#151a23] border border-[#1f2937] hover:bg-[#1f2531] hover:border-primary/30 hover:scale-[1.02] cursor-pointer transition-all duration-200"
    >
      {/* 3D Bust Model for all players */}
      <div className="relative w-12 h-16 rounded-md overflow-hidden shrink-0">
        <Image
          src={`https://render.crafty.gg/3d/bust/${encodeURIComponent(player.ign)}`}
          alt={player.ign}
          width={48}
          height={64}
          className="object-contain"
          style={{ imageRendering: 'pixelated' }}
          onError={(e) => {
            e.currentTarget.src = `https://mc-heads.net/avatar/${player.ign}/48`;
          }}
        />
      </div>

      <div className="flex-1 min-w-0">
        <h3 className="text-sm font-bold text-slate-100 break-words leading-tight">
          {player.ign}
        </h3>
        
        <div className="flex items-center gap-2 mt-1 flex-wrap">
          {player.region && (
            <div className={cn(
              "px-2 py-0.5 rounded-full text-xs font-bold",
              getRegionClasses(player.region)
            )}>
              {player.region}
            </div>
          )}
          
          {player.tier && (
            <div className={cn(
              "px-2 py-0.5 text-xs font-bold rounded border-2",
              tierClasses
            )}>
              {player.tier}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

const PlayerModal = ({ player, rank, category, onClose }: { player: ApiPlayer; rank: number; category: string; onClose: () => void }) => {
  const isOverall = category === "overall";
  const namemcUrl = `https://namemc.com/profile/${player.ign}`;
  
  return (
    <Dialog open={true} onOpenChange={onClose}>
      <DialogContent className="bg-gradient-to-br from-[#161d2b] to-[#1a2332] border-2 border-[#2d3748] max-w-xl p-0 overflow-hidden">
        <button
          onClick={onClose}
          className="absolute top-3 right-3 z-50 w-8 h-8 rounded-full bg-[#2d3748] hover:bg-[#3d4758] border border-[#4a5568] flex items-center justify-center transition-all"
        >
          <X className="w-4 h-4 text-foreground" />
        </button>

        <div className="flex flex-col items-center gap-4 py-6 px-6">
          {/* Player 3D Model - no shimmer */}
          <div className="relative">
            <a
              href={namemcUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="relative block w-[100px] h-[200px] rounded-lg overflow-hidden transition-all hover:scale-105"
            >
              <Image
                src={`https://render.crafty.gg/3d/bust/${encodeURIComponent(player.ign)}`}
                alt={player.ign}
                width={100}
                height={200}
                className="object-contain"
                style={{ imageRendering: 'pixelated' }}
                onError={(e) => {
                  e.currentTarget.src = `https://mc-heads.net/body/${player.ign}/100`;
                }}
              />
            </a>
          </div>

          {/* Player Name - smaller */}
          <h2 className="text-xl font-bold text-white text-center break-words max-w-full px-4">
            {player.ign}
          </h2>

          {/* Region Badge - smaller */}
          {player.region && (
            <div className={cn(
              "px-4 py-1 rounded-full text-sm font-bold",
              getRegionClasses(player.region)
            )}>
              {player.region === "NA" ? "North America" : player.region}
            </div>
          )}

          {/* NameMC Link - removed N icon */}
          <a 
            href={namemcUrl} 
            target="_blank" 
            rel="noopener noreferrer"
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#2d3748] hover:bg-[#3d4758] border border-[#4a5568] transition-all"
          >
            <span className="text-xs font-medium text-white">NameMC</span>
          </a>

          {/* Position Badge - smaller and cleaner */}
          <div className="w-full px-4 py-2.5 rounded-lg bg-[#1e293b] border border-[#334155]">
            <div className="text-center">
              <div className="text-sm text-muted-foreground mb-0.5">POSITION</div>
              <div className={cn(
                "text-2xl font-bold",
                rank === 1 ? "text-[#fbbf24]" :
                rank === 2 ? "text-[#94a3b8]" :
                rank === 3 ? "text-[#fb923c]" :
                "text-white"
              )}>
                {rank}. <span className="text-base font-semibold">OVERALL</span> <span className="text-sm text-muted-foreground">({player.total || 0} points)</span>
              </div>
            </div>
          </div>

          {/* Tiers Section - more compact */}
          <div className="w-full">
            <h3 className="text-xs font-bold mb-3 text-muted-foreground uppercase tracking-wider">
              TIERS
            </h3>
            
            {isOverall && player.modes && (
              <div className="grid grid-cols-4 gap-2">
                {Object.entries(player.modes).map(([mode, tier]) => {
                  const icon = gameModeIcons[mode.toLowerCase()];
                  const tierClasses = getTierClasses(tier);
                  
                  return (
                    <div key={mode} className="flex flex-col items-center gap-1.5 p-2 rounded-lg bg-[#1e293b]/30 border border-[#1f2937]">
                      {icon && (
                        <div className="w-8 h-8 relative opacity-80">
                          <Image
                            src={icon}
                            alt={mode}
                            width={32}
                            height={32}
                            className="object-contain"
                          />
                        </div>
                      )}
                      <div className={cn(
                        "px-2 py-0.5 rounded text-xs font-bold border w-full text-center",
                        tierClasses
                      )}>
                        {tier || "-"}
                      </div>
                    </div>
                  );
                })}
              </div>
            )}

            {!isOverall && (
              <div className="flex items-center justify-center gap-3 p-3 rounded-lg bg-[#1e293b]/30 border border-[#1f2937]">
                {gameModeIcons[category.toLowerCase()] && (
                  <div className="w-10 h-10 relative opacity-80">
                    <Image
                      src={gameModeIcons[category.toLowerCase()]}
                      alt={category}
                      width={40}
                      height={40}
                      className="object-contain"
                    />
                  </div>
                )}
                <div className={cn(
                  "px-4 py-1.5 rounded text-lg font-bold border-2",
                  getTierClasses(player.tier)
                )}>
                  {player.tier || "-"}
                </div>
              </div>
            )}
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default function RankingsTable({ category }: RankingsTableProps) {
  const [players, setPlayers] = useState<ApiPlayer[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [selectedPlayer, setSelectedPlayer] = useState<{ player: ApiPlayer; rank: number } | null>(null);

  const isOverall = category === "overall";

  useEffect(() => {
    const fetchRankings = async () => {
      setLoading(true);
      setError(null);
      
      try {
        const response = await fetch(`/api/rankings/${category}`);
        
        if (!response.ok) {
          const errorData = await response.json().catch(() => ({}));
          throw new Error(errorData.error || `Failed to fetch: ${response.status}`);
        }
        
        const data: ApiResponse = await response.json();
        setPlayers(data.players || []);
      } catch (err) {
        console.error("API Error:", err);
        setError(err instanceof Error ? err.message : "An error occurred");
      } finally {
        setLoading(false);
      }
    };

    fetchRankings();
    
    const interval = setInterval(fetchRankings, 30000);
    
    return () => clearInterval(interval);
  }, [category]);

  // Group players by tier for gamemode view
  const tierGroups = !isOverall ? {
    "T1": players.filter(p => p.tier?.endsWith("1")),
    "T2": players.filter(p => p.tier?.endsWith("2")),
    "T3": players.filter(p => p.tier?.endsWith("3")),
    "T4": players.filter(p => p.tier?.endsWith("4")),
    "T5": players.filter(p => p.tier?.endsWith("5")),
  } : {};

  return (
    <div className="bg-[#0f1419] text-white w-full">
      {error && (
        <div className="mb-4 p-4 bg-destructive/10 border border-destructive/30 rounded-lg text-center">
          <p className="text-destructive font-semibold">⚠️ API Connection Failed</p>
          <p className="text-sm text-muted-foreground mt-1">
            Unable to fetch data from server. Please try again later.
          </p>
          <p className="text-xs text-muted-foreground mt-1">
            Error: {error}
          </p>
        </div>
      )}
      
      {loading && players.length === 0 ? (
        <div className="flex items-center justify-center py-24">
          <div className="text-center">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto mb-4"></div>
            <p className="text-muted-foreground">Loading rankings...</p>
          </div>
        </div>
      ) : players.length === 0 ? (
        <div className="text-center py-24">
          <p className="text-muted-foreground text-lg">No players found</p>
        </div>
      ) : (
        <>
          {/* Overall view - numbered rows */}
          {isOverall && (
            <div className="space-y-2">
              {players.slice(0, 100).map((player, index) => (
                <PlayerRow
                  key={`${player.ign}-${index}`}
                  player={player}
                  rank={index + 1}
                  category={category}
                  onPlayerClick={() => setSelectedPlayer({ player, rank: index + 1 })}
                />
              ))}
            </div>
          )}

          {/* Gamemode view - tier cards with rows */}
          {!isOverall && (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5 gap-6">
              {Object.entries(tierGroups).map(([tierName, tierPlayers]) => {
                const tierNumber = tierName.substring(1);
                const tierBgClass = tierNumber === "1" ? "bg-[#0f0905]" :
                                   tierNumber === "2" ? "bg-[#1a1410]" :
                                   tierNumber === "3" ? "bg-[#2d2015]" :
                                   tierNumber === "4" ? "bg-[#3d3020]" :
                                   "bg-[#4d4025]";
                
                return (
                  <div 
                    key={tierName} 
                    className={cn(
                      "flex flex-col rounded-xl border-2 overflow-hidden",
                      tierBgClass
                    )}
                  >
                    {/* Tier Header */}
                    <div className={cn(
                      "py-4 px-4 border-b-2",
                      tierNumber === "1" ? "bg-[#1a0f05] border-[#fbbf24]" :
                      tierNumber === "2" ? "bg-[#2a2420] border-[#94a3b8]" :
                      tierNumber === "3" ? "bg-[#3d3025] border-[#fb923c]" :
                      tierNumber === "4" ? "bg-[#4d4030] border-[#94a3b8]" :
                      "bg-[#5d5035] border-[#fb923c]"
                    )}>
                      <h3 className={cn(
                        "text-2xl font-bold text-center",
                        tierNumber === "1" ? "text-[#fbbf24]" :
                        tierNumber === "2" ? "text-[#94a3b8]" :
                        tierNumber === "3" ? "text-[#fb923c]" :
                        tierNumber === "4" ? "text-[#94a3b8]" :
                        "text-[#fb923c]"
                      )}>
                        {tierName}
                      </h3>
                    </div>
                    
                    {/* Players List */}
                    <div className="p-4 space-y-3 flex-1">
                      {tierPlayers.length === 0 ? (
                        <div className="text-center py-12 text-muted-foreground text-sm">
                          No players yet
                        </div>
                      ) : (
                        tierPlayers.map((player, index) => (
                          <PlayerCard
                            key={`${player.ign}-${index}`}
                            player={player}
                            onPlayerClick={() => {
                              const globalRank = players.findIndex(p => p.ign === player.ign) + 1;
                              setSelectedPlayer({ player, rank: globalRank });
                            }}
                          />
                        ))
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </>
      )}

      {selectedPlayer && (
        <PlayerModal
          player={selectedPlayer.player}
          rank={selectedPlayer.rank}
          category={category}
          onClose={() => setSelectedPlayer(null)}
        />
      )}
    </div>
  );
}