export default function Footer() {
  return (
    <footer className="w-full border-t border-border mt-12">
      <div className="max-w-[1400px] mx-auto px-4 sm:px-6 lg:px-8 py-10">
        <div className="text-center">
          <p className="text-sm text-muted-foreground">
            Copyrights © Axis Tiers 2025 By NotQuant
          </p>
        </div>
      </div>
    </footer>
  );
}