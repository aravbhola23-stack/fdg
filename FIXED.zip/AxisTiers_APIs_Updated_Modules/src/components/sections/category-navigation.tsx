"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import Image from "next/image";

const categories = [
  {
    name: "Overall",
    href: "/rankings/overall",
    icon: "https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/425ffaba-197f-44f7-b59e-aabfd2a5bd4d-mctiers-com/assets/svgs/overall-4.svg?",
  },
  {
    name: "Crystal",
    href: "/rankings/crystal",
    icon: "https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/425ffaba-197f-44f7-b59e-aabfd2a5bd4d-mctiers-com/assets/svgs/vanilla-6.svg?",
  },
  {
    name: "UHC",
    href: "/rankings/uhc",
    icon: "https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/425ffaba-197f-44f7-b59e-aabfd2a5bd4d-mctiers-com/assets/svgs/uhc-7.svg?",
  },
  {
    name: "DiaPot",
    href: "/rankings/diapot",
    icon: "https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/425ffaba-197f-44f7-b59e-aabfd2a5bd4d-mctiers-com/assets/svgs/pot-8.svg?",
  },
  {
    name: "NethPot",
    href: "/rankings/nethpot",
    icon: "https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/425ffaba-197f-44f7-b59e-aabfd2a5bd4d-mctiers-com/assets/svgs/nethop-9.svg?",
  },
  {
    name: "SMP",
    href: "/rankings/smp",
    icon: "https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/425ffaba-197f-44f7-b59e-aabfd2a5bd4d-mctiers-com/assets/svgs/smp-10.svg?",
  },
  {
    name: "Sword",
    href: "/rankings/sword",
    icon: "https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/425ffaba-197f-44f7-b59e-aabfd2a5bd4d-mctiers-com/assets/svgs/sword-11.svg?",
  },
  {
    name: "Axe",
    href: "/rankings/axe",
    icon: "https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/425ffaba-197f-44f7-b59e-aabfd2a5bd4d-mctiers-com/assets/svgs/axe-12.svg?",
  },
];

export default function CategoryNavigation() {
  const pathname = usePathname();

  return (
    <nav className="w-full overflow-x-auto scrollbar-hide animate-fade-in">
      <div className="flex gap-4 p-6 min-w-max">
        {categories.map((category, index) => {
          const isActive = pathname === category.href;
          
          return (
            <Link
              key={category.name}
              href={category.href}
              className={`group flex flex-col items-center gap-3 transition-all duration-300 animate-fade-in-up hover:scale-110 ${
                isActive ? "scale-105" : ""
              }`}
              style={{ animationDelay: `${index * 0.05}s` }}
            >
              <div
                className={`relative flex h-16 w-16 items-center justify-center rounded-full transition-all duration-300 ${
                  isActive
                    ? "bg-[#1a1f2e] ring-2 ring-primary shadow-lg shadow-primary/50"
                    : "bg-[#1a1f2e] hover:bg-[#232936] hover:shadow-lg hover:shadow-primary/20"
                }`}
              >
                {isActive && (
                  <div className="absolute inset-0 rounded-full bg-primary/20 animate-pulse" />
                )}
                <Image
                  src={category.icon}
                  alt={category.name}
                  width={32}
                  height={32}
                  className={`object-contain transition-all duration-300 relative z-10 ${
                    isActive ? "scale-110" : "group-hover:scale-110 group-hover:rotate-12"
                  }`}
                />
              </div>
              <span
                className={`text-sm font-medium transition-colors duration-300 ${
                  isActive
                    ? "text-primary"
                    : "text-muted-foreground group-hover:text-foreground"
                }`}
              >
                {category.name}
              </span>
            </Link>
          );
        })}
      </div>
    </nav>
  );
}