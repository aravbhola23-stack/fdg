import NavigationHeader from "@/components/sections/navigation-header";
import CategoryNavigation from "@/components/sections/category-navigation";
import RankingsTable from "@/components/sections/rankings-table";
import Footer from "@/components/sections/footer";
import { notFound } from "next/navigation";

const validCategories = ["overall", "crystal", "uhc", "diapot", "nethpot", "smp", "sword", "axe"];

export default function RankingCategoryPage({ params }: { params: { category: string } }) {
  const category = params.category;

  if (!validCategories.includes(category)) {
    notFound();
  }

  return (
    <div className="min-h-screen bg-[#0a1120] text-foreground">
      <div className="w-full pt-4">
        <NavigationHeader />
      </div>

      <main className="max-w-[1400px] mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <CategoryNavigation />

        <div className="mt-8">
          <h1 className="text-3xl font-bold mb-6 capitalize text-center">
            {category} Rankings
          </h1>
          <RankingsTable category={category} />
        </div>
      </main>

      <Footer />
    </div>
  );
}

export function generateStaticParams() {
  return validCategories.map((category) => ({
    category,
  }));
}