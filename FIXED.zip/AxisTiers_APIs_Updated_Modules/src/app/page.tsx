import NavigationHeader from "@/components/sections/navigation-header";
import Footer from "@/components/sections/footer";
import Link from "next/link";
import Image from "next/image";

const gameModes = [
  { name: 'Crystal', icon: 'https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/425ffaba-197f-44f7-b59e-aabfd2a5bd4d-mctiers-com/assets/svgs/vanilla-6.svg?', href: '/rankings/crystal' },
  { name: 'UHC', icon: 'https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/425ffaba-197f-44f7-b59e-aabfd2a5bd4d-mctiers-com/assets/svgs/uhc-7.svg?', href: '/rankings/uhc' },
  { name: 'DiaPot', icon: 'https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/425ffaba-197f-44f7-b59e-aabfd2a5bd4d-mctiers-com/assets/svgs/pot-8.svg?', href: '/rankings/diapot' },
  { name: 'NethPot', icon: 'https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/425ffaba-197f-44f7-b59e-aabfd2a5bd4d-mctiers-com/assets/svgs/nethop-9.svg?', href: '/rankings/nethpot' },
  { name: 'SMP', icon: 'https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/425ffaba-197f-44f7-b59e-aabfd2a5bd4d-mctiers-com/assets/svgs/smp-10.svg?', href: '/rankings/smp' },
  { name: 'Sword', icon: 'https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/425ffaba-197f-44f7-b59e-aabfd2a5bd4d-mctiers-com/assets/svgs/sword-11.svg?', href: '/rankings/sword' },
  { name: 'Axe', icon: 'https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/425ffaba-197f-44f7-b59e-aabfd2a5bd4d-mctiers-com/assets/svgs/axe-12.svg?', href: '/rankings/axe' },
];

export default function Home() {
  return (
    <div className="min-h-screen bg-[#0a1120] text-foreground">
      <div className="w-full pt-4">
        <NavigationHeader />
      </div>

      <main className="max-w-[1400px] mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {/* Hero Section */}
        <section className="text-center py-12 px-4">
          <h1 className="text-5xl md:text-7xl font-extrabold mb-6 bg-gradient-to-r from-[#84cc16] to-[#fbbf24] bg-clip-text text-transparent animate-gradient">
            Axis Tiers
          </h1>
          <p className="text-xl md:text-2xl text-muted-foreground mb-12 animate-fade-in">
            Click A Mode To Open Its Tier Page.
          </p>

          {/* Game Mode Grid */}
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6 max-w-5xl mx-auto">
            {gameModes.map((mode, index) => (
              <Link
                key={mode.name}
                href={mode.href}
                className="bg-[#1a1f2e] border border-border rounded-2xl p-8 hover:border-primary/50 transition-all duration-300 hover:scale-110 hover:shadow-xl hover:shadow-primary/20 group animate-fade-in-up"
                style={{ animationDelay: `${index * 0.1}s` }}
              >
                <div className="flex flex-col items-center gap-4">
                  <div className="w-20 h-20 flex items-center justify-center relative">
                    <div className="absolute inset-0 bg-primary/10 rounded-full blur-xl opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
                    <Image
                      src={mode.icon}
                      alt={mode.name}
                      width={64}
                      height={64}
                      className="object-contain group-hover:scale-125 transition-transform duration-300 relative z-10 group-hover:rotate-12"
                    />
                  </div>
                  <span className="text-xl font-bold text-foreground group-hover:text-primary transition-colors duration-300">
                    {mode.name}
                  </span>
                </div>
              </Link>
            ))}
          </div>
        </section>
      </main>

      <Footer />
    </div>
  );
}