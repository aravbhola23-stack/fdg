export async function GET(req: Request, context: any) {
    const { category } = context.params;

export async function GET(
  request: Request,
  { params }: { params: { category: string } }
) {
  const { category } = params;

  try {
    const baseUrl = "https://kodak-mechanics-bird-document.trycloudflare.com";
    
    const apiUrl = category === "overall"
      ? `${baseUrl}/api/overall`
      : `${baseUrl}/api/gamemode/${category}`;

    const response = await fetch(apiUrl, {
      headers: {
        "Content-Type": "application/json",
      },
      cache: "no-store", // Always fetch fresh data
    });

    if (!response.ok) {
      throw new Error(`API returned ${response.status}`);
    }

    const data = await response.json();

    return NextResponse.json(data, {
      headers: {
        "Cache-Control": "no-store, max-age=0",
      },
    });
  } catch (error) {
    console.error("API Proxy Error:", error);
    return NextResponse.json(
      { error: "Failed to fetch rankings data" },
      { status: 500 }
    );
  }
}