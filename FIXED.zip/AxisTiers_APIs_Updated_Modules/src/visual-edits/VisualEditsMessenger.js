'use client';
import { useEffect } from 'react';

const API_BASE = typeof window !== 'undefined' ? window.__API_BASE__ || 'https://kodak-mechanics-bird-document.trycloudflare.com' : 'https://kodak-mechanics-bird-document.trycloudflare.com';

export default function VisualEditsMessenger() {
  useEffect(() => {
    let lastSnapshot = null;
    let isMounted = true;

    async function fetchSnapshot() {
      try {
        const res = await fetch(API_BASE + '/api/overall');
        if (!res.ok) return;
        const json = await res.json();
        const snapshot = JSON.stringify(json);
        if (lastSnapshot !== null && lastSnapshot !== snapshot) {
          // dispatch a custom event so other components can react
          window.dispatchEvent(new CustomEvent('axis:api-update', { detail: { previous: lastSnapshot, current: snapshot } }));
        }
        lastSnapshot = snapshot;
      } catch (e) {
        // ignore errors, will try again later
        console.error('VisualEditsMessenger fetch failed', e);
      }
    }

    // Initial fetch and then poll
    fetchSnapshot();
    const interval = setInterval(() => { if (isMounted) fetchSnapshot(); }, 10000);

    return () => {
      isMounted = false;
      clearInterval(interval);
    };
  }, []);

  return null;
}
